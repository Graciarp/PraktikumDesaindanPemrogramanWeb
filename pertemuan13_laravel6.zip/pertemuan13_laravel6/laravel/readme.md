# Praktikum Desain dan Pemrograman Web

## Gracia Rizka Pasfica

## 19104064

# Pertemuan 13 Laravel 6
Disini saya menggunakan projek dari pertemuan 12 <a href="https://github.com/Graciarp/PraktikumDesaindanPemrogramanWeb/tree/main/pertemuan12_laravel5">ini </a> yang saya unggah ke hosting, dan bisa diakses melalui link dibawah ini


