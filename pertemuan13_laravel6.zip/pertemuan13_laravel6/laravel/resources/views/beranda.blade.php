@extends('base')

@section('content')
    <h1>
        Gracia Rizka Pasfica    
    </h1>
@endsection