<?php $__env->startSection('content'); ?>
    <h1>
        Gracia Rizka Pasfica    
    </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/PraktikumDesaindanPemrogramanWebGracia/pertemuan11_laravel4/resources/views/beranda.blade.php ENDPATH**/ ?>